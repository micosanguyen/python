package vn.com.examplebank.client.android.utils.zdefender

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import androidx.core.view.isVisible
import com.examplebank.log_app.LogApp
import com.zimperium.api.v5.ZDefendThreat
import vn.com.examplebank.client.android.R
import vn.com.examplebank.client.android.databinding.DialogThreatProtectBinding
import vn.com.examplebank.client.android.databinding.LayoutThreatNameItemBinding
import vn.com.examplebank.client.android.utils.ExampleBankBUtils

class ThreatProtectDialog(
    context: Context,
    private var threatsData: MutableList<ZDefendThreatExt>,
    val callback: () -> Unit
) : Dialog(context) {


    companion object {
        private const val MAX_ITEM_SHOW_COLLAPSE = 3
        private const val URL_LINK = "https://go.examplebank.com.vn/podcasts/example-security-awareness-podcast"
        private const val ACCESSIBILITY_ACTIVE = "ACCESSIBILITY_ACTIVE"
        private const val ACCESSIBILITY_ACTIVE_SIDELOADED = "ACCESSIBILITY_ACTIVE_SIDELOADED"
        private const val SIDELOADED_APP = "SIDELOADED_APP"
        private const val ALERT_TEXT = "AlertText"
        private const val BUTTON_LABEL = "buttonLabel"
        private const val BUTTON_LINK = "buttonLink"
        private const val THREAT_NAME = "threatName"
    }

    var listThreats = mutableMapOf<String, MutableList<ZDefendThreat>>()


    private lateinit var binding: DialogThreatProtectBinding
    private var isCollapse = true
    private var isLanguageVietnam = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setCancelable(false)
        setCanceledOnTouchOutside(false)
        window?.let {
            it.setGravity(Gravity.BOTTOM)
            it.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            it.attributes.windowAnimations = R.style.DialogAnimation
        }

        binding = DialogThreatProtectBinding.inflate(
            LayoutInflater.from(
                context
            ), null, false
        )
        setContentView(
            binding.root,
            LinearLayout.LayoutParams(getScreenWidth(), ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // init listener
        initListener(binding)

        // show data on view
        initView(binding)
    }

    fun updateData(data: MutableList<ZDefendThreatExt>) {
        initListener(binding)
        // show data on view
        threatsData = data
        initView(binding)
    }

    private fun checkOneThreat(threatsData: MutableList<ZDefendThreatExt>): Boolean =
        threatsData.size == 1

    private fun initView(binding: DialogThreatProtectBinding) {
        isLanguageVietnam = ExampleBankBUtils.isVietnamese(context)

        with(binding) {
            // show giao diện theo data threat
            if (threatsData.size == 1) {
                /*** single threat ***/
                val item = threatsData.first()
                if (item.zDefendThreat.severity.name == ZDefendThreat.ZThreatSeverity.IMPORTANT.name) {
                    if (item.zDefendThreat.malwareName.isNotEmpty()) {
                        btnTiepTucSuDung.tag = "200"
                        btnTiepTucSuDung.text = context.getString(R.string.zdefend_uninstall)
                        btnTiepTucSuDung.isVisible = false
                    } else {
                        if (ACCESSIBILITY_ACTIVE == item.zDefendThreat.internalName || ACCESSIBILITY_ACTIVE_SIDELOADED == item.zDefendThreat.internalName) {
                            btnTiepTucSuDung.tag = "100"
                            btnTiepTucSuDung.text = context.getString(R.string.aas_open_setting)
                            btnTiepTucSuDung.isVisible = true
                        }
                    }
                    tvMessage.text = AppProtectUtils.getThreatJsonValue(item.zDefendThreat.localizedAlertText, ALERT_TEXT, isLanguageVietnam)
                    val localizedAlertButtonText = AppProtectUtils.getThreatJsonValue(item.zDefendThreat.localizedAlertButtonText, BUTTON_LABEL, isLanguageVietnam)
                    tvMoreInfo.text = localizedAlertButtonText
                    layoutMoreInfo.isVisible = !localizedAlertButtonText.isNullOrEmpty()

                } else {
                    if (item.zDefendThreat.malwareName.isNotEmpty()) {
                        btnTiepTucSuDung.tag = "200"
                        btnTiepTucSuDung.text = context.getString(R.string.zdefend_uninstall)
                    } else {
                        if (ACCESSIBILITY_ACTIVE == item.zDefendThreat.internalName || ACCESSIBILITY_ACTIVE_SIDELOADED == item.zDefendThreat.internalName) {
                            btnTiepTucSuDung.tag = "100"
                            btnTiepTucSuDung.text = context.getString(R.string.aas_open_setting)
                        }
                    }
                    tvMessage.text = AppProtectUtils.getThreatJsonValue(item.zDefendThreat.localizedAlertText, ALERT_TEXT, isLanguageVietnam)
                    val localizedAlertButtonText = AppProtectUtils.getThreatJsonValue(item.zDefendThreat.localizedAlertButtonText, BUTTON_LABEL, isLanguageVietnam)
                    tvMoreInfo.text = localizedAlertButtonText
                    layoutMoreInfo.isVisible = !localizedAlertButtonText.isNullOrEmpty()
                    btnTiepTucSuDung.isVisible = true
                }
            } else {
                /*** Multi threats ***/
                val checkImportance = threatsData.any {
                    it.zDefendThreat.severity.name == ZDefendThreat.ZThreatSeverity.IMPORTANT.name
                }
                if (checkImportance) {
                    btnTiepTucSuDung.isVisible = false
                } else {
                    btnTiepTucSuDung.isVisible = true
                }
            }
            showListThreatsName(threatsData)
            // check collapse expand
            handleCollapseExpand()
        }
    }

    private fun initListener(binding: DialogThreatProtectBinding) {
        with(binding) {
            // icon close
            ExampleBankBUtils.setSafeOnClick(imgClose) {
                dismiss()
            }
            // tìm hiểu thêm
            ExampleBankBUtils.setSafeOnClick(layoutMoreInfo) {
                if (checkOneThreat(threatsData)) {
                    val buttonLink = AppProtectUtils.getThreatJsonValue(threatsData.first().zDefendThreat.localizedAlertButtonLink, BUTTON_LINK, isLanguageVietnam)
                    if (!buttonLink.isNullOrEmpty()) {
                        ExampleBankBUtils.openUrl(context, buttonLink)
                    }
                } else {
                    ExampleBankBUtils.openUrl(context, URL_LINK)
                }
            }

            // button tiếp tục sử dụng
            ExampleBankBUtils.setSafeOnClick(btnTiepTucSuDung) {
                if (btnTiepTucSuDung.tag == "100") {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    ExampleBankBUtils.startActivityImplicit(context, intent)
                } else if (btnTiepTucSuDung.tag == "200") {
                    val item = threatsData.first()
                    if (item.zDefendThreat.packageName.isNotEmpty()) {
                        ExampleBankBUtils.openDetailApp(
                            AppProtectUtils.getInstance().getCurrentActivity(),
                            item.zDefendThreat.packageName
                        )
                    }

                } else {
                    dismiss()
                }
            }

            // button đóng ứng dụng
            ExampleBankBUtils.setSafeOnClick(btnDongUngDung) {
                dismiss()

                Process.killProcess(Process.myPid())
                System.exit(0)
            }

            // collapse/expand
            ExampleBankBUtils.setSafeOnClick(layoutCollapseExpand) {
                isCollapse = !isCollapse
                handleCollapseExpand()
            }

            ExampleBankBUtils.setSafeOnClick(tvCollapseExpand) {
                isCollapse = !isCollapse
                handleCollapseExpand()
            }
        }
    }

    private fun navigateItem(item: ZDefendThreat?) {
        item?.let {
            if (it.malwareName.isNotEmpty() && it.packageName.isNotEmpty()) {
                ExampleBankBUtils.openDetailApp(
                    AppProtectUtils.getInstance().getCurrentActivity(),
                    it.packageName
                )
            } else {
                when (it.internalName) {
                    ACCESSIBILITY_ACTIVE, ACCESSIBILITY_ACTIVE_SIDELOADED -> {
                        callback()
                    }
                    SIDELOADED_APP -> {
                        if (it.packageName.isNotEmpty()) {
                            ExampleBankBUtils.openDetailApp(
                                AppProtectUtils.getInstance().getCurrentActivity(),
                                it.packageName
                            )
                        }
                    }

                    else -> {
                        val buttonLink = AppProtectUtils.getThreatJsonValue(it.localizedAlertButtonLink, BUTTON_LINK, isLanguageVietnam)
                        if (!buttonLink.isNullOrEmpty()) {
                            ExampleBankBUtils.openUrl(context, buttonLink)
                        }
                    }
                }
            }
        }
    }

    public fun getList(): MutableList<ZDefendThreatExt> = threatsData


    private lateinit var lists: MutableList<ZDefendThreatExt>


    // hiển thị list threat
    private fun showListThreatsName(lstThreatsName: MutableList<ZDefendThreatExt>) {
        try {
            lists = mutableListOf()
            val importance =
                lstThreatsName.filter { it.zDefendThreat.severity.name == ZDefendThreat.ZThreatSeverity.IMPORTANT.name }
            val lows =
                lstThreatsName.filter { it.zDefendThreat.severity.name == ZDefendThreat.ZThreatSeverity.LOW.name }
            if (importance.isNotEmpty()) {
                lists.addAll(importance.toMutableList())
            }
            if (lows.isNotEmpty()) {
                lists.addAll(lows)
            }
            binding.layoutThreatsName.removeAllViews()
            lists.forEach { threat ->
                val itemBinding = LayoutThreatNameItemBinding.inflate(
                    LayoutInflater.from(context),
                    binding.layoutThreatsName,
                    false
                )
                itemBinding.tvThreatName.text = AppProtectUtils.getThreatJsonValue(threat.zDefendThreat.localizedAlertText, THREAT_NAME, isLanguageVietnam)

                if (ACCESSIBILITY_ACTIVE == threat.zDefendThreat.internalName || ACCESSIBILITY_ACTIVE_SIDELOADED == threat.zDefendThreat.internalName) {

                    itemBinding.llSecond.isVisible = threat.name.isNotEmpty()
                    itemBinding.tvThreatDetail.text = threat.name
                    itemBinding.tvCount.isVisible = threat.count > 4
                    itemBinding.tvCount.text = "+${threat.count - 4}"
                } else if (threat.zDefendThreat.internalName == SIDELOADED_APP) {

                    itemBinding.llSecond.isVisible = threat.zDefendThreat.appName.isNotEmpty()
                    itemBinding.tvThreatDetail.text = threat.zDefendThreat.appName
                    itemBinding.tvCount.isVisible = false
                } else if (threat.zDefendThreat.malwareName.isNotEmpty()) {
                    itemBinding.llSecond.isVisible = threat.zDefendThreat.malwareName.isNotEmpty()
                    itemBinding.tvThreatDetail.text = threat.zDefendThreat.appName
                    itemBinding.tvCount.isVisible = false
                } else {
                    itemBinding.llSecond.isVisible = false
                }
                ExampleBankBUtils.setSafeOnClick(itemBinding.llGroup) {
                    navigateItem(threat.zDefendThreat)
                }
                binding.layoutThreatsName.addView(itemBinding.root)
            }

            // nếu không có threat nào
            if (threatsData.isEmpty() || threatsData.size == 1) {
                ExampleBankBUtils.setGone(
                    binding.tvListThreat,
                    binding.layoutScrollThreats,
                    binding.layoutCollapseExpand
                )
                return
            }

            ExampleBankBUtils.setVisible(
                binding.tvListThreat, binding.layoutScrollThreats, binding.layoutCollapseExpand
            )

            // nếu số threat < fix thì không cần show text collapse/expande
            if (binding.layoutThreatsName.childCount <= MAX_ITEM_SHOW_COLLAPSE) {
                ExampleBankBUtils.setGone(binding.layoutCollapseExpand)
                return
            }

            // show text collapse/expand
            ExampleBankBUtils.setVisible(binding.layoutCollapseExpand)
        } catch (e: Exception) {
            LogApp.e("crashappp: ", e)
        }
    }

    private fun handleCollapseExpand() {
        // show/hide view
        for (i in 0 until binding.layoutThreatsName.childCount) {
            binding.layoutThreatsName.getChildAt(i).isVisible =
                i < MAX_ITEM_SHOW_COLLAPSE || !isCollapse
        }
        // update button
        binding.tvCollapseExpand.setText(if (isCollapse) R.string.s2_lbl_xem_them else R.string.s2_lbl_thu_gon)
        binding.imgThreatName.animate().cancel()
        binding.imgThreatName.animate().rotation(if (isCollapse) 0F else 180F)
            .setDuration(300).start()
    }

    private fun getScreenWidth(): Int {
        val displayMetrics = DisplayMetrics()
        window?.windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        return displayMetrics.widthPixels
    }
}