package vn.com.examplebank.client.android.utils.zdefender

import android.content.Intent
import android.provider.Settings
import androidx.fragment.app.FragmentActivity
import com.examplebank.log_app.LogApp
import com.zimperium.api.v5.ZDefend
import com.zimperium.api.v5.ZDefendThreat
import com.zimperium.api.v5.ZDeviceStatus
import com.zimperium.api.v5.ZDeviceStatusCallback
import vn.com.examplebank.client.android.BuildConfig
import vn.com.examplebank.client.android.ocbrequest.ocbrequest.JsonHelper
import vn.com.examplebank.client.android.ui.ExampleBankLauncherActivity
import vn.com.examplebank.client.android.utils.EnvConfig
import vn.com.examplebank.client.android.utils.ExampleBankBUtils
import java.lang.ref.Reference
import java.lang.ref.SoftReference

class AppProtectUtils : ZDeviceStatusCallback {
    private var currentActivity: Reference<FragmentActivity>? = null
    private var dialog: Reference<ThreatProtectDialog>? = null
    init {
        if (BuildConfig.AppEnv != EnvConfig.UAT) {
            ZDefend.addDeviceStatusCallback(this)
        } else {
            LogApp.e("""
                $IGNORE_ZDEFEND
            """)
        }
    }
    var checkApp: Boolean = false

    fun getDialog() = dialog?.get()

    fun setCurrentActivity(currentActivity: FragmentActivity?) {
        this.currentActivity = SoftReference(currentActivity)
    }

    fun getCurrentActivity() = currentActivity?.get()

    override fun onDeviceStatus(deviceStatus: ZDeviceStatus) {
        // filter all threats Importance

        val threats =
            deviceStatus.activeNewThreats.filter { ZDefendThreat.ZThreatSeverity.IMPORTANT.name == it.severity.name || ZDefendThreat.ZThreatSeverity.LOW.name == it.severity.name }
        deviceStatus.activeNewThreats.forEach {
            LogApp.e(it.severity.name)
        }
//        log("onDeviceStatus - activeNewThreats = ${deviceStatus.activeNewThreats.size}; threats = ${threats.size}")
        val check = deviceStatus.activeNewThreats.any {
            it.internalName == "APP_TAMPERING" || it.internalName == "DEVICE_EMULATOR" || it.internalName == "DEVICE_ROOTED" ||
                    it.internalName == "DEBUG_ENABLED_APK" || it.internalName == "USB_DEBUGGING_ON" || it.internalName == "WIFI_DEBUGGING_ON" ||
                    it.internalName == "ANDROID_DEBUG_BRIDGE_APPS_NOT_VERIFIED"
        }

        if (!checkApp && check) {
            checkApp = check
        }
        if (threats.isNotEmpty()) {
            showDialogWarning(getAllThreatsName(threats))
        }
    }


    private fun showDialogWarning(threats: MutableList<ZDefendThreatExt>) {
        try {
            if (threats.isNotEmpty()) {
                currentActivity?.get()?.let { activity ->
                    activity.runOnUiThread {
                        if (dialog == null || dialog?.get() == null) {
                            LogApp.e("First...")
                            dialog = SoftReference(ThreatProtectDialog(activity, threats) {
                                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                ExampleBankBUtils.startActivityImplicit(activity, intent)
                            })
                            if (currentActivity != null && !activity.isFinishing && activity !is ExampleBankLauncherActivity) {
                                dialog?.get()?.show()
                            }
                        } else {
                            LogApp.e("Second...")
                            if (dialog != null && dialog?.get()?.isShowing == true) {
                                dialog?.get()?.getList()?.let { list ->
                                    threats.forEach { item ->
                                        val isCheck =
                                            list.none { it.zDefendThreat.uuid.equals(item.zDefendThreat.uuid) }
                                        if (isCheck) {
                                            if (item.zDefendThreat.internalName == "ACCESSIBILITY_ACTIVE") {
                                                val listData =
                                                    list.filter { it.zDefendThreat.internalName == "ACCESSIBILITY_ACTIVE" }
                                                val pkg = item.zDefendThreat.packageName
                                                val appName = item.zDefendThreat.appName
                                                val result =
                                                    if (appName.isNotEmpty()) appName else pkg
                                                if (listData.isNotEmpty()) {
                                                    val zDefendThreat = listData.first()
                                                    zDefendThreat.name =
                                                        zDefendThreat.name + "; " + result
                                                    zDefendThreat.count += 1
                                                    val index = list.indexOf(zDefendThreat)
                                                    list[index] = zDefendThreat
                                                } else {
                                                    item.name = result
                                                    list.add(
                                                        ZDefendThreatExt(
                                                            item.zDefendThreat,
                                                            result,
                                                            item.count + 1
                                                        )
                                                    )
                                                }
                                            } else if ("ACCESSIBILITY_ACTIVE_SIDELOADED" == item.zDefendThreat.internalName) {
                                                val listData =
                                                    list.filter { it.zDefendThreat.internalName == "ACCESSIBILITY_ACTIVE_SIDELOADED" }
                                                val pkg = item.zDefendThreat.packageName
                                                val appName = item.zDefendThreat.appName
                                                val result =
                                                    if (appName.isNotEmpty()) appName else pkg

                                                if (listData.isNotEmpty()) {
                                                    val zDefendThreat = listData.first()
                                                    zDefendThreat.name =
                                                        zDefendThreat.name + "; " + result
                                                    zDefendThreat.count += 1
                                                    val index = list.indexOf(zDefendThreat)
                                                    list[index] = zDefendThreat
                                                } else {
                                                    item.name = result
                                                    list.add(
                                                        ZDefendThreatExt(
                                                            item.zDefendThreat,
                                                            result,
                                                            item.count + 1
                                                        )
                                                    )
                                                }
                                            } else {
                                                list.add(ZDefendThreatExt(item.zDefendThreat))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            LogApp.e(e)
        }
    }

    private fun getAllThreatsName(lstThreats: List<ZDefendThreat>): MutableList<ZDefendThreatExt> {

        val actives = lstThreats.filter { it.internalName == "ACCESSIBILITY_ACTIVE" }
        val sideLoaded = lstThreats.filter { it.internalName == "ACCESSIBILITY_ACTIVE_SIDELOADED" }
        val threats = mutableListOf<ZDefendThreatExt>()

        val filterOthers =
            lstThreats.filter { it.internalName != "ACCESSIBILITY_ACTIVE" && "ACCESSIBILITY_ACTIVE_SIDELOADED" != it.internalName }
        filterOthers.forEach {
            threats.add(ZDefendThreatExt(it, ""))
        }

        if (actives.isNotEmpty()) {
            threats.add(ZDefendThreatExt(actives[0], getName(actives), actives.size))
        }

        if (sideLoaded.isNotEmpty()) {
            threats.add(ZDefendThreatExt(sideLoaded[0], getName(sideLoaded), sideLoaded.size))
        }
        return threats
    }

    private fun getName(threats: List<ZDefendThreat>): String {
        var name = ""
        threats.forEach {
            val pkg = it.packageName
            val appName = it.appName
            val result = if (appName.isNotEmpty()) appName else pkg
            name = if (name.isEmpty()) {
                result
            } else {
                "$name; $result"
            }
        }
        return name
    }

    companion object {
        private var _instance: AppProtectUtils? = null

        @JvmStatic
        fun getInstance() = _instance ?: AppProtectUtils().also { _instance = it }

        @JvmStatic
        fun getThreatJsonValue(jsonData: String?, jsonKey: String, isVietnam: Boolean) =
            JsonHelper.getStringValue(jsonKey, null, JsonHelper.getJSONObjectValue(if (isVietnam) "vi-VN" else "en-US", jsonData))
                ?: jsonData

        @JvmStatic
        fun setTrackingIds(cif: String?, appProtectDeviceID: String?) {
            ZDefend.setTrackingIds(cif, appProtectDeviceID)
        }

        private const val IGNORE_ZDEFEND = """
+======================================================+
|░▀█▀░█▀▀░█▀█░█▀█░█▀▄░█▀▀░░░▀▀█░█▀▄░█▀▀░█▀▀░█▀▀░█▀█░█▀▄|
|░░█░░█░█░█░█░█░█░█▀▄░█▀▀░░░▄▀░░█░█░█▀▀░█▀▀░█▀▀░█░█░█░█|
|░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░▀░▀▀▀░░░▀▀▀░▀▀░░▀▀▀░▀░░░▀▀▀░▀░▀░▀▀░|
+======================================================+
        """
    }
}

data class ZDefendThreatExt(
    val zDefendThreat: ZDefendThreat,
    var name: String = "",
    var count: Int = 0
)
